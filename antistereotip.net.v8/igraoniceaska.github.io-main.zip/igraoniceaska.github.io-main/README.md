# igraoniceaska.github.io

Jednostavan statički bootstrap sajt. Onepager sa jasnim linkovanjem i page-scroll efektom.

<img src="https://github.com/igraoniceaska/igraoniceaska.github.io/blob/main/aska.png" width="150" height="auto" alt="logotip"/>

### Ovo je Askin statički sajt. Ovde mašta prelazi u stvarnost. 

### Kontaktirajte nas na +381643939674
